package com.yuanrongbank.mapper;

import com.yuanrongbank.model.yrAuthor;

public interface yrAuthorMapper {
    int deleteByPrimaryKey(Integer recid);

    int insert(yrAuthor record);

    int insertSelective(yrAuthor record);

    yrAuthor selectByPrimaryKey(Integer recid);

    int updateByPrimaryKeySelective(yrAuthor record);

    int updateByPrimaryKeyWithBLOBs(yrAuthor record);

    int updateByPrimaryKey(yrAuthor record);
}