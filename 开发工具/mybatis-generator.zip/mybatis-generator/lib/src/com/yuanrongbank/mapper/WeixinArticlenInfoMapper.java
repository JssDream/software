package com.yuanrongbank.mapper;

import com.yuanrongbank.model.WeixinArticlenInfo;

public interface WeixinArticlenInfoMapper {
    int deleteByPrimaryKey(Integer recid);

    int insert(WeixinArticlenInfo record);

    int insertSelective(WeixinArticlenInfo record);

    WeixinArticlenInfo selectByPrimaryKey(Integer recid);

    int updateByPrimaryKeySelective(WeixinArticlenInfo record);

    int updateByPrimaryKeyWithBLOBs(WeixinArticlenInfo record);

    int updateByPrimaryKey(WeixinArticlenInfo record);
}