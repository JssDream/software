package com.yuanrongbank.mapper;

import com.yuanrongbank.model.ShortVideoDetailInfo;

public interface ShortVideoDetailInfoMapper {
    int deleteByPrimaryKey(Integer recid);

    int insert(ShortVideoDetailInfo record);

    int insertSelective(ShortVideoDetailInfo record);

    ShortVideoDetailInfo selectByPrimaryKey(Integer recid);

    int updateByPrimaryKeySelective(ShortVideoDetailInfo record);

    int updateByPrimaryKey(ShortVideoDetailInfo record);
}