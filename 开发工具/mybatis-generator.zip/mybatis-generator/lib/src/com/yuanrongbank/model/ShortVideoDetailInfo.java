package com.yuanrongbank.model;

import java.util.Date;

public class ShortVideoDetailInfo {
    private Integer recid;

    private String url;

    private Integer svid;

    private Integer platformname;

    private String tag;

    private String title;

    private String author;

    private String imgurl;

    private String imglocalurl;

    private String videourl;

    private Integer paybacknum;

    private Integer commentnum;

    private Integer forwardingnum;

    private Integer likenum;

    private Date publishtime;

    private Date createtime;

    private Date updatetime;

    private Integer statusvalue;

    private Integer yuanrongplatformauthorinfo;

    public Integer getRecid() {
        return recid;
    }

    public void setRecid(Integer recid) {
        this.recid = recid;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url == null ? null : url.trim();
    }

    public Integer getSvid() {
        return svid;
    }

    public void setSvid(Integer svid) {
        this.svid = svid;
    }

    public Integer getPlatformname() {
        return platformname;
    }

    public void setPlatformname(Integer platformname) {
        this.platformname = platformname;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag == null ? null : tag.trim();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title == null ? null : title.trim();
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author == null ? null : author.trim();
    }

    public String getImgurl() {
        return imgurl;
    }

    public void setImgurl(String imgurl) {
        this.imgurl = imgurl == null ? null : imgurl.trim();
    }

    public String getImglocalurl() {
        return imglocalurl;
    }

    public void setImglocalurl(String imglocalurl) {
        this.imglocalurl = imglocalurl == null ? null : imglocalurl.trim();
    }

    public String getVideourl() {
        return videourl;
    }

    public void setVideourl(String videourl) {
        this.videourl = videourl == null ? null : videourl.trim();
    }

    public Integer getPaybacknum() {
        return paybacknum;
    }

    public void setPaybacknum(Integer paybacknum) {
        this.paybacknum = paybacknum;
    }

    public Integer getCommentnum() {
        return commentnum;
    }

    public void setCommentnum(Integer commentnum) {
        this.commentnum = commentnum;
    }

    public Integer getForwardingnum() {
        return forwardingnum;
    }

    public void setForwardingnum(Integer forwardingnum) {
        this.forwardingnum = forwardingnum;
    }

    public Integer getLikenum() {
        return likenum;
    }

    public void setLikenum(Integer likenum) {
        this.likenum = likenum;
    }

    public Date getPublishtime() {
        return publishtime;
    }

    public void setPublishtime(Date publishtime) {
        this.publishtime = publishtime;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public Integer getStatusvalue() {
        return statusvalue;
    }

    public void setStatusvalue(Integer statusvalue) {
        this.statusvalue = statusvalue;
    }

    public Integer getYuanrongplatformauthorinfo() {
        return yuanrongplatformauthorinfo;
    }

    public void setYuanrongplatformauthorinfo(Integer yuanrongplatformauthorinfo) {
        this.yuanrongplatformauthorinfo = yuanrongplatformauthorinfo;
    }
}