package com.yuanrongbank.model;

import java.math.BigDecimal;
import java.util.Date;

public class yrAuthor {
    private Integer recid;

    private String authornickname;

    private String authorimg;

    private Integer authorcreationtime;

    private BigDecimal createdprice;

    private Date createdtime;

    private Date modifytime;

    private Integer statusindex;

    private Integer registereduserinfoid;

    private String creationtimeremark;

    private String createdpriceremark;

    private Integer authorstatus;

    private Integer authorauditfailreason;

    private Integer yrindex;

    private String introduction;

    public Integer getRecid() {
        return recid;
    }

    public void setRecid(Integer recid) {
        this.recid = recid;
    }

    public String getAuthornickname() {
        return authornickname;
    }

    public void setAuthornickname(String authornickname) {
        this.authornickname = authornickname == null ? null : authornickname.trim();
    }

    public String getAuthorimg() {
        return authorimg;
    }

    public void setAuthorimg(String authorimg) {
        this.authorimg = authorimg == null ? null : authorimg.trim();
    }

    public Integer getAuthorcreationtime() {
        return authorcreationtime;
    }

    public void setAuthorcreationtime(Integer authorcreationtime) {
        this.authorcreationtime = authorcreationtime;
    }

    public BigDecimal getCreatedprice() {
        return createdprice;
    }

    public void setCreatedprice(BigDecimal createdprice) {
        this.createdprice = createdprice;
    }

    public Date getCreatedtime() {
        return createdtime;
    }

    public void setCreatedtime(Date createdtime) {
        this.createdtime = createdtime;
    }

    public Date getModifytime() {
        return modifytime;
    }

    public void setModifytime(Date modifytime) {
        this.modifytime = modifytime;
    }

    public Integer getStatusindex() {
        return statusindex;
    }

    public void setStatusindex(Integer statusindex) {
        this.statusindex = statusindex;
    }

    public Integer getRegistereduserinfoid() {
        return registereduserinfoid;
    }

    public void setRegistereduserinfoid(Integer registereduserinfoid) {
        this.registereduserinfoid = registereduserinfoid;
    }

    public String getCreationtimeremark() {
        return creationtimeremark;
    }

    public void setCreationtimeremark(String creationtimeremark) {
        this.creationtimeremark = creationtimeremark == null ? null : creationtimeremark.trim();
    }

    public String getCreatedpriceremark() {
        return createdpriceremark;
    }

    public void setCreatedpriceremark(String createdpriceremark) {
        this.createdpriceremark = createdpriceremark == null ? null : createdpriceremark.trim();
    }

    public Integer getAuthorstatus() {
        return authorstatus;
    }

    public void setAuthorstatus(Integer authorstatus) {
        this.authorstatus = authorstatus;
    }

    public Integer getAuthorauditfailreason() {
        return authorauditfailreason;
    }

    public void setAuthorauditfailreason(Integer authorauditfailreason) {
        this.authorauditfailreason = authorauditfailreason;
    }

    public Integer getYrindex() {
        return yrindex;
    }

    public void setYrindex(Integer yrindex) {
        this.yrindex = yrindex;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction == null ? null : introduction.trim();
    }
}