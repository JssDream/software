package com.yuanrongbank.model;

import java.math.BigDecimal;
import java.util.Date;

public class WeixinArticlenInfo {
    private Integer recid;

    private String url;

    private String title;

    private String headimg;

    private String headimglocal;

    private Integer readnum;

    private Integer likenum;

    private Integer comnum;

    private String abstract;

    private Integer copyright;

    private Integer resource;

    private String tag;

    private Date publishtime;

    private Date updatetime;

    private BigDecimal score;

    private String author;

    private Integer categoryid;

    private String headimgnew1;

    private String headimgnew2;

    private String headimgnew3;

    private Integer yuanrongplatformauthorinfoId;

    private String content;

    public Integer getRecid() {
        return recid;
    }

    public void setRecid(Integer recid) {
        this.recid = recid;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url == null ? null : url.trim();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title == null ? null : title.trim();
    }

    public String getHeadimg() {
        return headimg;
    }

    public void setHeadimg(String headimg) {
        this.headimg = headimg == null ? null : headimg.trim();
    }

    public String getHeadimglocal() {
        return headimglocal;
    }

    public void setHeadimglocal(String headimglocal) {
        this.headimglocal = headimglocal == null ? null : headimglocal.trim();
    }

    public Integer getReadnum() {
        return readnum;
    }

    public void setReadnum(Integer readnum) {
        this.readnum = readnum;
    }

    public Integer getLikenum() {
        return likenum;
    }

    public void setLikenum(Integer likenum) {
        this.likenum = likenum;
    }

    public Integer getComnum() {
        return comnum;
    }

    public void setComnum(Integer comnum) {
        this.comnum = comnum;
    }

    public String getAbstract() {
        return abstract;
    }

    public void setAbstract(String abstract) {
        this.abstract = abstract == null ? null : abstract.trim();
    }

    public Integer getCopyright() {
        return copyright;
    }

    public void setCopyright(Integer copyright) {
        this.copyright = copyright;
    }

    public Integer getResource() {
        return resource;
    }

    public void setResource(Integer resource) {
        this.resource = resource;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag == null ? null : tag.trim();
    }

    public Date getPublishtime() {
        return publishtime;
    }

    public void setPublishtime(Date publishtime) {
        this.publishtime = publishtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public BigDecimal getScore() {
        return score;
    }

    public void setScore(BigDecimal score) {
        this.score = score;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author == null ? null : author.trim();
    }

    public Integer getCategoryid() {
        return categoryid;
    }

    public void setCategoryid(Integer categoryid) {
        this.categoryid = categoryid;
    }

    public String getHeadimgnew1() {
        return headimgnew1;
    }

    public void setHeadimgnew1(String headimgnew1) {
        this.headimgnew1 = headimgnew1 == null ? null : headimgnew1.trim();
    }

    public String getHeadimgnew2() {
        return headimgnew2;
    }

    public void setHeadimgnew2(String headimgnew2) {
        this.headimgnew2 = headimgnew2 == null ? null : headimgnew2.trim();
    }

    public String getHeadimgnew3() {
        return headimgnew3;
    }

    public void setHeadimgnew3(String headimgnew3) {
        this.headimgnew3 = headimgnew3 == null ? null : headimgnew3.trim();
    }

    public Integer getYuanrongplatformauthorinfoId() {
        return yuanrongplatformauthorinfoId;
    }

    public void setYuanrongplatformauthorinfoId(Integer yuanrongplatformauthorinfoId) {
        this.yuanrongplatformauthorinfoId = yuanrongplatformauthorinfoId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }
}